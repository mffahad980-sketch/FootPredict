const API_BASE = 'https://api.football-data.org/v4';

function dhakaDate(offsetDays = 0) {
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Dhaka', year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(now);
  const values = Object.fromEntries(parts.map((p) => [p.type, p.value]));
  const base = new Date(`${values.year}-${values.month}-${values.day}T00:00:00Z`);
  base.setUTCDate(base.getUTCDate() + offsetDays);
  return base.toISOString().slice(0, 10);
}

export default async (request) => {
  if (request.method !== 'GET') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  const token = process.env.FOOTBALL_DATA_TOKEN;
  if (!token) {
    return Response.json({ error: 'Football data token is not configured in Netlify.' }, { status: 500 });
  }

  const url = new URL(request.url);
  const dateFrom = url.searchParams.get('dateFrom') || dhakaDate(0);
  const dateTo = url.searchParams.get('dateTo') || dhakaDate(3);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateFrom) || !/^\d{4}-\d{2}-\d{2}$/.test(dateTo)) {
    return Response.json({ error: 'Dates must use YYYY-MM-DD format.' }, { status: 400 });
  }
  if (dateFrom > dateTo) {
    return Response.json({ error: 'dateFrom must be before or equal to dateTo.' }, { status: 400 });
  }

  try {
    const upstream = await fetch(`${API_BASE}/matches?dateFrom=${dateFrom}&dateTo=${dateTo}`, {
      headers: { 'X-Auth-Token': token, 'Accept': 'application/json' }
    });
    const raw = await upstream.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = { message: raw.slice(0, 300) }; }

    if (!upstream.ok) {
      const message = data.message || data.error || `Football data provider returned ${upstream.status}.`;
      return Response.json({ error: message, providerStatus: upstream.status }, { status: upstream.status === 429 ? 429 : 502 });
    }

    const matches = (data.matches || []).map((m) => ({
      id: m.id,
      utcDate: m.utcDate,
      status: m.status,
      matchday: m.matchday,
      competition: m.competition?.name || 'Competition',
      homeTeam: m.homeTeam?.name || 'Home team',
      awayTeam: m.awayTeam?.name || 'Away team',
      homeScore: m.score?.fullTime?.home ?? null,
      awayScore: m.score?.fullTime?.away ?? null
    }));

    return Response.json({
      source: 'football-data.org',
      dateFrom,
      dateTo,
      count: matches.length,
      matches
    }, { headers: { 'Cache-Control': 'public, max-age=120' } });
  } catch (error) {
    return Response.json({ error: 'Could not contact the football data provider. Please try again later.' }, { status: 502 });
  }
};
